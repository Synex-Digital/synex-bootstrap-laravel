@extends('Frontend.layout.app')

@section('content')
    <div class="calendly-inline-widget" data-url="https://calendly.com/synexdigital" style="min-width:320px;height:700px;">
    </div>
    <script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script>
@endsection
