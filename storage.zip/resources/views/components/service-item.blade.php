<div class="service-item">
    <svg class="pb-4" width="62" height="62" viewBox="0 0 62 62" fill="none" xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink">
        <rect width="62" height="62" fill="url(#pattern0_1100_93)" />
        <defs>
            <pattern id="pattern0_1100_93" patternContentUnits="objectBoundingBox" width="1" height="1">
                <use xlink:href="#image0_1100_93" transform="scale(0.0104167)" />
            </pattern>
            <image id="image0_1100_93" width="96" height="96"
                xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAGJklEQVR4nO2caYhcRRDHO973gfeFCCIiiiIigniAKCosSnBFk81Uz0ZXNCwiSkRU4gX5oBEhiAaUjfOqJ2E0mojGg5wmQTCgGKNgiKjxAqMxHrv7qiZuS8+u2VnYefN239Hvvekf9KewpOrf9Xq6qqtbCIfD4XA4HA6Hw+FwOBwOh6PDAa9+nVRckchfAfJPEvlTQFo0tzJ8rm3bCk1PRR8Jil+XivVkAxQxID9o285C0rdEHyEVrW8l/oSJQFpk295C0V3Th0hFq8OIv38gP2bb7kLQt0QfDMhvT0n88fGwbftzTXdNHwiKl09TfC2RRgB5nm0/csmCBfoAQPamLX7TJEjF99j2J19oPQOQXo4s/vju6N9ylXpsu5UbpKLn4hK/6UvYB4rusO1b5pFIC2MXvylPkMrvsu1jZpFITyYlftOXQFLVb7bta+YoIz+QuPjjkzAEXv1a2z5nBqhyf2ri7x/0j/T4KtHplBWVx7aKKU9Ao2Sxt7fKl6XudP9qfajIAIA0x2wRbYjf9CX8Bso/P3FnS1i/yaT0ZtbH/uNhQNoEivtMui9Spuz5t5mtoV3xx74ExdsS08BEe6N2Hvwpbi0tHTxDpIRUftfoltC++E0a3J1MIUvxynAG8I7Znj5NJIys1q83X59twSdZitbYL2Qhb+9T+kSRECXkq0HRoH2xJ52APfF5qvUMqXhgWoaY470BfZyIGfD4ClD0l32hJx8mMOIsZL0YMRo+7n1FHx2PQUJIjy6Viv6wLXKbwPs8FmdB0bOxRATShu6aPjyqPb0VuhCQdlsXuP0X8ETmaimA9H6UnGHOMv88ifSLbXFD+Ll7zmv6hEjiA/L8RAxEfms6e+SeyvA5oPiHHEQ+l7z6DVHFn5eoochvLFivDwprz13e4Jmg+Bvb4rb3i/ZJpFmRxJceQRrpPCheao4J29nTU9Enm4apHIg/Ejn5KlfpzjTTeahyf5A9JocAxV/kQfyy4nsjiQ/KvzXNdB6QNt1X00e1FL+mjzUlDevihvKF50dO5wHJT1H8LUF5wWjLIH1kW9hQvih+NJL4gHylOdFJUfxNQeKPtQxutC1sqIH0TCTxZyl9fLr7atoYtOyYRA2Q1loXNkwgKXpe5OLQelz8dWZpaWULDOjDptyvaW3QS6ZEE8ME8PZUogVprVlagiJfKvrAvrChxkCY7XO4CmejpcKu+H2ja/6aDAjb3hfFy01ZXsRF0jsfs5Npt+bL/Ii/MvZjRlMyTc5oWh8U+TC65udj2UF6L5HGA7OHTSRakDYE/eD2N86Vc/ODuy6OMvqkzPb0MYC8K2aDN7YTH5DetS9sqEDaErSExoJpJAKkv9NY8/tN5CO9kxPxt5pyiEiDRjZsWuuiRf7moAy3u3Evi1fZFjZcIPG2yAcqabZ3tKvt5Ep85B1Q06cKG0j0b5lqRTSM+GF7iaRt8RV/14tDZwublKp0e9gzgSJFvlT8vXXx/6ekqNTuVAwUfRL0I5Uv8ennzD1LYG4CtmzzRv62XNMntfpbkzGaw3f7wnLbAUi/lj3/ApFFpOL7JzHYL1fo4kDxFb+Zk8jfE+RLJpDIj0yMfnqqTfPuipyI/2dJ8eUiDxjRx6J/b6t1v9G8i1zNxbKjaLCs+BqRJ0yLIiAtbvnvSItzEvnD5n0gkTu0ntHqh9dc07QvLHfuldI8dDAAUl2iP1MUDVN8s38xjpNvGcwqjY7lbIs/Ij3qFUWltzp4epbFh8K/7zN6fenHbE4APyQ6AVD0tHWx1cQBih8XncLo0WaGGmmRFopOw9yETLbLgsNFPtILolMxiRoo/tLisvNqLC2DecY8USCRd1qYgEo8LYMFQC4bOsucGaQY+SumcuesIzAnTI2HsPPatVYEkr7XC0gfmhZH235mGol0kXnESMY+AbQ5qAPP0QQgXWKO/2IUP9a3JzoCiO91k8/M1Srb/uQSiNgCaaVlsGjI6bZAIn9trWWwaEC1fuOUbucg7zRlb9t2FwqJ/szGMWHbrSbvMi+l2La3kEjld5n+nKAfXJNV27az0Myt6lMaL5ybK7PmDWak3839MlvvjzocDofD4XA4HA6Hw+FwOBwiBv4DlrrBzCPBkCMAAAAASUVORK5CYII=" />
        </defs>
    </svg>
    <h5 class="pb-2">{{ $title }}</h5>
    <p class="sr-box-desc">{{ $description }}</p>
</div>
