<?php $__env->startSection('content'); ?>
    <?php
        $blogs = [
            [
                'title' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam.',
                'category' => 'category',
                'date' => '18 Jan 2022',
                'view' => '12,322',
                'image' => '12,322',
            ],
            [
                'title' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam.',
                'category' => 'category',
                'date' => '18 Jan 2022',
                'view' => '12,322',
                'image' => '12,322',
            ],
            [
                'title' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam.',
                'category' => 'category',
                'date' => '18 Jan 2022',
                'view' => '12,322',
                'image' => '12,322',
            ],
            [
                'title' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam.',
                'category' => 'category',
                'date' => '18 Jan 2022',
                'view' => '12,322',
                'image' => '12,322',
            ],
            [
                'title' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam.',
                'category' => 'category',
                'date' => '18 Jan 2022',
                'view' => '12,322',
                'image' => '12,322',
            ],
            [
                'title' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam.',
                'category' => 'category',
                'date' => '18 Jan 2022',
                'view' => '12,322',
                'image' => '12,322',
            ],
        ];
        $blogHero = [
            [
                'title' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam.',
                'category' => 'category',
                'date' => '18 Jan 2022',
                'view' => '12,322',
                'image' => '12,322',
            ],
            [
                'title' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam.',
                'category' => 'category',
                'date' => '18 Jan 2022',
                'view' => '12,322',
                'image' => '12,322',
            ],
            [
                'title' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam.',
                'category' => 'category',
                'date' => '18 Jan 2022',
                'view' => '12,322',
                'image' => '12,322',
            ],
        ];
    ?>
    <?php echo $__env->make('Frontend.layout.calendly', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Featured Blogs Section -->
    <div class="container my-5">
        <h2 class="text-center mb-4">Our Featured <span class="text-primary">Blogs</span></h2>
        <?php if($bestBlog): ?>
            <?php if($bestBlog['bestOne']): ?>
                <div class="row mb-4 align-items-center">
                    <div class="col-lg-6 p-4">
                        <a href="blog-details.html" class="text-decoration-none">
                            <div class="card border-0 bg-light">
                                <img src="<?php echo e($bestBlog['bestOne']['image']); ?>" class="card-img-top rounded"
                                    alt="Featured Image">
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-6 p-md-4 px-4 px-md-0">
                        <a href="<?php echo e(route('blog.view', $bestBlog['bestOne']['slug'])); ?>" class="text-decoration-none">
                            <h3 class="card-title text-dark py-md-4 pb-0 pb-md-2" style="font-size: 22px !important">
                                <?php echo e($bestBlog['bestOne']['title']); ?></h3>
                        </a>
                        <p class="card-text mt-3"><?php echo e($bestBlog['bestOne']['description']); ?></p>
                        <div class="d-flex justify-content-between py-2">
                            <div class="card-pan"><?php echo e($bestBlog['bestOne']['author']); ?> • <?php echo e($bestBlog['bestOne']['date']); ?>

                            </div>
                            <small class="text-muted">
                                <svg fill="#252222c2" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg"
                                    xmlns:xlink="http://www.w3.org/1999/xlink" width="18px" height="18px"
                                    viewBox="0 0 442.04 442.04" xml:space="preserve">
                                    <g>
                                        <g>
                                            <path
                                                d="M221.02,341.304c-49.708,0-103.206-19.44-154.71-56.22C27.808,257.59,4.044,230.351,3.051,229.203
                                                                                                                                                                           c-4.068-4.697-4.068-11.669,0-16.367c0.993-1.146,24.756-28.387,63.259-55.881c51.505-36.777,105.003-56.219,154.71-56.219
                                                                                                                                                                           c49.708,0,103.207,19.441,154.71,56.219c38.502,27.494,62.266,54.734,63.259,55.881c4.068,4.697,4.068,11.669,0,16.367
                                                                                                                                                                           c-0.993,1.146-24.756,28.387-63.259,55.881C324.227,321.863,270.729,341.304,221.02,341.304z M29.638,221.021
                                                                                                                                                                           c9.61,9.799,27.747,27.03,51.694,44.071c32.83,23.361,83.714,51.212,139.688,51.212s106.859-27.851,139.688-51.212
                                                                                                                                                                           c23.944-17.038,42.082-34.271,51.694-44.071c-9.609-9.799-27.747-27.03-51.694-44.071
                                                                                                                                                                           c-32.829-23.362-83.714-51.212-139.688-51.212s-106.858,27.85-139.688,51.212C57.388,193.988,39.25,211.219,29.638,221.021z" />
                                        </g>
                                        <g>
                                            <path
                                                d="M221.02,298.521c-42.734,0-77.5-34.767-77.5-77.5c0-42.733,34.766-77.5,77.5-77.5c18.794,0,36.924,6.814,51.048,19.188
                                                                                                                                                                           c5.193,4.549,5.715,12.446,1.166,17.639c-4.549,5.193-12.447,5.714-17.639,1.166c-9.564-8.379-21.844-12.993-34.576-12.993
                                                                                                                                                                           c-28.949,0-52.5,23.552-52.5,52.5s23.551,52.5,52.5,52.5c28.95,0,52.5-23.552,52.5-52.5c0-6.903,5.597-12.5,12.5-12.5
                                                                                                                                                                           s12.5,5.597,12.5,12.5C298.521,263.754,263.754,298.521,221.02,298.521z" />
                                        </g>
                                        <g>
                                            <path
                                                d="M221.02,246.021c-13.785,0-25-11.215-25-25s11.215-25,25-25c13.786,0,25,11.215,25,25S234.806,246.021,221.02,246.021z" />
                                        </g>
                                    </g>
                                </svg>
                                <?php echo e($bestBlog['bestOne']['view']); ?> views</small>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="row">
                <?php if($bestBlog['bestThree']): ?>
                    <?php $__currentLoopData = $bestBlog['bestThree']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4">
                            <?php if (isset($component)) { $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864 = $attributes; } ?>
<?php $component = App\View\Components\Blog::resolve(['title' => ''.e($blog['title']).'','slug' => ''.e($blog['slug']).'','category' => ''.e($blog['category']).'','date' => ''.e($blog['date']).'','views' => ''.e($blog['view']).'','image' => ''.e($blog['image']).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Blog::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $attributes = $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $component = $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Latest Blogs Section -->
    <div class="container my-5" id="content">
        <h2 class="text-center mb-4">Latest <span class="text-primary">Blogs</span></h2>
        <div class="row">
            <!-- Repeated Blog Cards -->
            <?php $__currentLoopData = $latestBlog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <?php if (isset($component)) { $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864 = $attributes; } ?>
<?php $component = App\View\Components\Blog::resolve(['title' => ''.e($blog['title']).'','slug' => ''.e($blog['slug']).'','category' => ''.e($blog['category']).'','date' => ''.e($blog['date']).'','views' => ''.e($blog['view']).'','image' => ''.e($blog['image']).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Blog::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $attributes = $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $component = $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="text-center mt-4">
            <?php if(!empty($pagination) && $pagination['total_pages'] > 1): ?>
                <nav class="py-3">
                    <ul class="pagination">
                        <li class="page-item">
                            <a class="page-link <?php echo e($pagination['current_page'] == 1 ? 'disabled' : ''); ?>"
                                href="<?php echo e(url()->current()); ?>?page=<?php echo e($pagination['current_page'] - 1); ?>#content"
                                rel="prev">&laquo;
                                Previous</a>
                        </li>
                        <?php for($page = 1; $page <= $pagination['total_pages']; $page++): ?>
                            <?php if($page == $pagination['current_page']): ?>
                                <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
                            <?php else: ?>
                                <li class="page-item"><a class="page-link"
                                        href="<?php echo e(url()->current()); ?>?page=<?php echo e($page); ?>#content"><?php echo e($page); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        <li class="page-item">
                            <a class="page-link <?php echo e($pagination['current_page'] == $pagination['total_pages'] ? 'disabled' : ''); ?>"
                                href="<?php echo e(url()->current()); ?>?page=<?php echo e($pagination['current_page'] + 1); ?>#content"
                                rel="next">Next
                                &raquo;</a>
                        </li>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>

    <!-- Collaborate -->
    <?php if (isset($component)) { $__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c = $attributes; } ?>
<?php $component = App\View\Components\Collaborate::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('collaborate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Collaborate::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c)): ?>
<?php $attributes = $__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c; ?>
<?php unset($__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c)): ?>
<?php $component = $__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c; ?>
<?php unset($__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c); ?>
<?php endif; ?>

    <!-- News Letter-->
    <?php if (isset($component)) { $__componentOriginal476d5595d47c472a8f67121eca35cf7d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal476d5595d47c472a8f67121eca35cf7d = $attributes; } ?>
<?php $component = App\View\Components\Newsletter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('newsletter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Newsletter::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal476d5595d47c472a8f67121eca35cf7d)): ?>
<?php $attributes = $__attributesOriginal476d5595d47c472a8f67121eca35cf7d; ?>
<?php unset($__attributesOriginal476d5595d47c472a8f67121eca35cf7d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal476d5595d47c472a8f67121eca35cf7d)): ?>
<?php $component = $__componentOriginal476d5595d47c472a8f67121eca35cf7d; ?>
<?php unset($__componentOriginal476d5595d47c472a8f67121eca35cf7d); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\synex-bootstrap-laravel\resources\views/Frontend/pages/blogs.blade.php ENDPATH**/ ?>