<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="row">
            <div class="col-lg-12  text-center">
                <h1 class="about-us-title"><?php echo e($category['name']); ?></h1>
                <img class="underlinesvg" src="http://127.0.0.1:8000/Frontend/images/aboutus-underline.svg" alt="">
            </div>
        </div>
    </div>
    <!-- Blog Details Section -->
    <section class="container py-2 py-md-4">
        <div class="row g-3">
            
            <div class="col-md-8 px-3 px-md-2">
                <div class="row">
                    <!-- Repeated Blog Cards -->
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4">
                            <?php if (isset($component)) { $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864 = $attributes; } ?>
<?php $component = App\View\Components\Blog::resolve(['title' => ''.e($blog['title']).'','slug' => ''.e($blog['slug']).'','category' => ''.e($blog['category']).'','date' => ''.e($blog['date']).'','views' => ''.e($blog['view']).'','image' => ''.e($blog['image']).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Blog::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $attributes = $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $component = $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if(!empty($pagination) && $pagination['total_pages'] > 1): ?>
                    <nav class="py-3">
                        <ul class="pagination">
                            <li class="page-item">
                                <a class="page-link <?php echo e($pagination['current_page'] == 1 ? 'disabled' : ''); ?>"
                                    href="<?php echo e(url()->current()); ?>?page=<?php echo e($pagination['current_page'] - 1); ?>#content"
                                    rel="prev">&laquo;
                                    Previous</a>
                            </li>
                            <?php for($page = 1; $page <= $pagination['total_pages']; $page++): ?>
                                <?php if($page == $pagination['current_page']): ?>
                                    <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
                                <?php else: ?>
                                    <li class="page-item"><a class="page-link"
                                            href="<?php echo e(url()->current()); ?>?page=<?php echo e($page); ?>#content"><?php echo e($page); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <li class="page-item">
                                <a class="page-link <?php echo e($pagination['current_page'] == $pagination['total_pages'] ? 'disabled' : ''); ?>"
                                    href="<?php echo e(url()->current()); ?>?page=<?php echo e($pagination['current_page'] + 1); ?>#content"
                                    rel="next">Next
                                    &raquo;</a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>

            
            <div class="col-md-4">
                <div class="row px-md-2">
                    
                    <div class="col-12 mb-4">
                        <div class="card card-second rounded shadow-sm h-auto">
                            <div class="card-body p-md-4 text-center">
                                People Management What is Website Flipping? How to Earn from Website Flipping People
                                Management What is Website Flipping? How to Earn from Website Flipping
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-12 mb-4 ">
                        <div class="card card-second rounded py-2 shadow-sm h-auto">
                            <div class="card-body p-md-4 text-center">
                                <h5 class="text-center">
                                    <div>Popular</div>
                                    <img src="<?php echo e(asset('Frontend/images/wave.png')); ?>" width="43px" class="pt-2"
                                        alt="wave">
                                </h5>

                                <div class="pt-4 text-start">
                                    
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-12 mb-4">
                        <div class="card card-second rounded py-2 shadow-sm h-auto">
                            <div class="card-body p-md-4 text-center">
                                <h5 class="text-center">
                                    <div>Category</div>
                                    <img src="<?php echo e(asset('Frontend/images/wave.png')); ?>" width="43px" class="pt-2"
                                        alt="wave">
                                </h5>

                                <div class="pt-4 text-start">
                                    <ul class="cat-list">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="d-flex">
                                                <a class="cat-list-item" href="<?php echo e(route('category', $category['slug'])); ?>">
                                                    <svg class="mr-4" width="20px" height="20px" viewBox="0 0 24 24"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path opacity="0.5"
                                                            d="M4 11.25C3.58579 11.25 3.25 11.5858 3.25 12C3.25 12.4142 3.58579 12.75 4 12.75V11.25ZM4 12.75H20V11.25H4V12.75Z"
                                                            fill="#1C274C" />
                                                        <path d="M14 6L20 12L14 18" stroke="#1C274C" stroke-width="1.5"
                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                    <span class="pl-3"><?php echo e($category['name']); ?></span>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- Collaborate -->
    <?php if (isset($component)) { $__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c = $attributes; } ?>
<?php $component = App\View\Components\Collaborate::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('collaborate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Collaborate::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c)): ?>
<?php $attributes = $__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c; ?>
<?php unset($__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c)): ?>
<?php $component = $__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c; ?>
<?php unset($__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c); ?>
<?php endif; ?>

    <!-- News Letter-->
    <?php if (isset($component)) { $__componentOriginal476d5595d47c472a8f67121eca35cf7d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal476d5595d47c472a8f67121eca35cf7d = $attributes; } ?>
<?php $component = App\View\Components\Newsletter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('newsletter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Newsletter::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal476d5595d47c472a8f67121eca35cf7d)): ?>
<?php $attributes = $__attributesOriginal476d5595d47c472a8f67121eca35cf7d; ?>
<?php unset($__attributesOriginal476d5595d47c472a8f67121eca35cf7d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal476d5595d47c472a8f67121eca35cf7d)): ?>
<?php $component = $__componentOriginal476d5595d47c472a8f67121eca35cf7d; ?>
<?php unset($__componentOriginal476d5595d47c472a8f67121eca35cf7d); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\synex-bootstrap-laravel\resources\views\Frontend\pages\category.blade.php ENDPATH**/ ?>