<div class="e-card playing">
    <a href="<?php echo e($url); ?>">
        <div class="image"></div>
        <div class="wave wave-<?php echo e($id); ?>"></div>
        <div class="wave wave-<?php echo e($id); ?>"></div>
        <div class="wave wave-<?php echo e($id); ?>"></div>
        <div class="infotop">
            <?php if($icon): ?>
                <img class="mb-4" src="<?php echo e($icon); ?>" alt="<?php echo e($title); ?>">
            <?php endif; ?>
            <br>
            <?php echo e($title); ?>

            <br>
            <div class="name"><?php echo e($description); ?></div>
        </div>
    </a>
</div>
<?php /**PATH D:\Project\synex-bootstrap-laravel\resources\views/components/service-card.blade.php ENDPATH**/ ?>