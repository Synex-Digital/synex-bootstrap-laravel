<div class="custom-card">
    <div class="testimonial-desc pb-3"><?php echo e($message); ?></div>
    <div class="d-flex gap-2">
        <img src="<?php echo e($image); ?>" alt="Synex Digital Profile" width="56" height="56">
        <div>
            <div class="testimonial-title"><?php echo e($client); ?></div>
            <div class="rating"><?php echo e($title); ?></div>
        </div>
    </div>
</div>
<?php /**PATH D:\Project\synex-bootstrap-laravel\resources\views/components/testimonial.blade.php ENDPATH**/ ?>