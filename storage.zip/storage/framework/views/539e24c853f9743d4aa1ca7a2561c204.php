<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo e(asset('Frontend/images/icons/fav-low.png')); ?>" type="image/x-icon">
    <meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">
    <link rel="stylesheet" rel="preconnect" href="<?php echo e(asset('Frontend')); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" rel="preconnect" href="<?php echo e(asset('Frontend')); ?>/css/custom.css">
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-0D02Y90D7E"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-0D02Y90D7E');
    </script>
    <?php echo SEOMeta::generate(); ?>

    <?php echo OpenGraph::generate(); ?>

    <?php echo Twitter::generate(); ?>

    <?php echo JsonLd::generate(); ?>

    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-16659065389"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'AW-16659065389');
    </script>
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>
    <script>
        function gtag_report_conversion(url) {
            var callback = function() {
                if (typeof(url) != 'undefined') {
                    window.location = url;
                }
            };
            gtag('event', 'conversion', {
                'send_to': 'AW-16659065389/sThcCM2S1NAZEK3U1Ic-',
                'event_callback': callback
            });
            return false;
        }
    </script>
    <?php echo $__env->make('Frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="nav-gap"></div>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('Frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>

    <!-- Javascript File -->
    <script src="<?php echo e(asset('Frontend')); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('Frontend')); ?>/js/jquery.min.js"></script>
    <script src="<?php echo e(asset('Frontend')); ?>/js/popper.min.js"></script>
    <script src="<?php echo e(asset('Frontend')); ?>/js/custom.js"></script>


    

</body>

</html>
<?php /**PATH D:\Project\synex-bootstrap-laravel\resources\views/Frontend/layout/app.blade.php ENDPATH**/ ?>