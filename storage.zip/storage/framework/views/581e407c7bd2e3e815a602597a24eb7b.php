<?php $__env->startSection('content'); ?>
    <div class="calendly-inline-widget" data-url="https://calendly.com/synexdigital" style="min-width:320px;height:700px;">
    </div>
    <script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\synex-bootstrap-laravel\resources\views\Frontend\pages\schedule.blade.php ENDPATH**/ ?>