<?php $__env->startSection('style'); ?>
    <style>
        #content {
            scroll-behavior: smooth;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="container-fluid service-hero" style="background-image: url(<?php echo e(asset('Frontend')); ?>/images/hero.webp);">
        <div class="shadow">
            <div class="container py-5 h-100 d-flex flex-column justify-content-center">
                <div class="row py-4 py-md-5">
                    <div class="col-md-6 py-md-5 m-auto text-center">
                        <h1 class="section-title text-white pb-2">Our <span class="font-main">Project</span></h1>
                        <h2 class="caption">Unlock Your Business Potential with Our Specialized Services and Strategic
                            Expertise</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 m-auto text-center">
                        <p class="scroll-text">Scroll Down</p>
                        <a href="#content"><svg class="scrolldown" width="23" height="22" viewBox="0 0 23 22"
                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M11.5 7V15M11.5 15L15 11.5M11.5 15L8 11.5" stroke="white" stroke-width="1.5"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M1.5 11C1.5 16.5228 5.97715 21 11.5 21C17.0228 21 21.5 16.5228 21.5 11C21.5 5.47715 17.0228 1 11.5 1C5.97715 1 1.5 5.47715 1.5 11Z"
                                    stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <section class="container py-4" id="content">
        <div class="row">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <?php if (isset($component)) { $__componentOriginalb009b6bea983337cad65fcfb8a10d717 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb009b6bea983337cad65fcfb8a10d717 = $attributes; } ?>
<?php $component = App\View\Components\ProjectCard::resolve(['title' => ''.e($project['title']).'','name' => ''.e($project['name']).'','description' => ''.e($project['description']).'','category' => ''.e($project['category']).'','image' => ''.e($project['image']).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('project-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProjectCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb009b6bea983337cad65fcfb8a10d717)): ?>
<?php $attributes = $__attributesOriginalb009b6bea983337cad65fcfb8a10d717; ?>
<?php unset($__attributesOriginalb009b6bea983337cad65fcfb8a10d717); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb009b6bea983337cad65fcfb8a10d717)): ?>
<?php $component = $__componentOriginalb009b6bea983337cad65fcfb8a10d717; ?>
<?php unset($__componentOriginalb009b6bea983337cad65fcfb8a10d717); ?>
<?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if(!empty($pagination) && $pagination['total_pages'] > 1): ?>
            <nav class="py-3">
                <ul class="pagination">
                    
                    
                    <li class="page-item">
                        <a class="page-link <?php echo e($pagination['current_page'] == 1 ? 'disabled' : ''); ?>"
                            href="<?php echo e(url()->current()); ?>?page=<?php echo e($pagination['current_page'] - 1); ?>#content"
                            rel="prev">&laquo;
                            Previous</a>
                    </li>
                    

                    
                    <?php for($page = 1; $page <= $pagination['total_pages']; $page++): ?>
                        <?php if($page == $pagination['current_page']): ?>
                            <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
                        <?php else: ?>
                            <li class="page-item"><a class="page-link"
                                    href="<?php echo e(url()->current()); ?>?page=<?php echo e($page); ?>"><?php echo e($page); ?></a></li>
                        <?php endif; ?>
                    <?php endfor; ?>

                    
                    
                    <li class="page-item">
                        <a class="page-link <?php echo e($pagination['current_page'] == $pagination['total_pages'] ? 'disabled' : ''); ?>"
                            href="<?php echo e(url()->current()); ?>?page=<?php echo e($pagination['current_page'] + 1); ?>#content"
                            rel="next">Next
                            &raquo;</a>
                    </li>
                    
                </ul>
            </nav>
        <?php endif; ?>
    </section>

    <!-- Collaborate -->
    <?php if (isset($component)) { $__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c = $attributes; } ?>
<?php $component = App\View\Components\Collaborate::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('collaborate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Collaborate::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c)): ?>
<?php $attributes = $__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c; ?>
<?php unset($__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c)): ?>
<?php $component = $__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c; ?>
<?php unset($__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c); ?>
<?php endif; ?>

    <!-- News Letter-->
    <?php if (isset($component)) { $__componentOriginal476d5595d47c472a8f67121eca35cf7d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal476d5595d47c472a8f67121eca35cf7d = $attributes; } ?>
<?php $component = App\View\Components\Newsletter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('newsletter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Newsletter::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal476d5595d47c472a8f67121eca35cf7d)): ?>
<?php $attributes = $__attributesOriginal476d5595d47c472a8f67121eca35cf7d; ?>
<?php unset($__attributesOriginal476d5595d47c472a8f67121eca35cf7d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal476d5595d47c472a8f67121eca35cf7d)): ?>
<?php $component = $__componentOriginal476d5595d47c472a8f67121eca35cf7d; ?>
<?php unset($__componentOriginal476d5595d47c472a8f67121eca35cf7d); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            if (window.location.hash === "#content") {
                $('html, body').animate({
                    scrollTop: $('#content').offset().top
                }, 800); // 800ms for the animation duration
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\synex-bootstrap-laravel\resources\views/Frontend/pages/projects.blade.php ENDPATH**/ ?>