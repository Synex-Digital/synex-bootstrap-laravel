<?php $__env->startSection('content'); ?>
    <section class="container py-4 py-md-5">
        <div class="row">
            <div class="col-md-6 m-auto text-center">
                
                <img src="<?php echo e(asset('Frontend/images/thank2.png')); ?>" alt="Synex Digital - Thanks image" width="60%">
                <div>
                    <h1>Thank You</h1>
                    <p>We Have recieved your message. We will reach you out immidiately.</p>
                </div>
            </div>
        </div>

        
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\synex-bootstrap-laravel\resources\views/Frontend/pages/thankyou.blade.php ENDPATH**/ ?>