<div class="mb-3 d-flex gap-3">
    <img src="<?php echo e($image); ?>" class="rounded" loading="lazy" width="58px" height="58px" alt="title">
    <div>
        <a href="<?php echo e(route('blog.view', $slug)); ?>" class="card-title-sm font-600"><?php echo e($title); ?></a>
        <p><?php echo e($date); ?></p>
    </div>
</div>
<?php /**PATH D:\Project\synex-bootstrap-laravel\resources\views\components\blog-list.blade.php ENDPATH**/ ?>