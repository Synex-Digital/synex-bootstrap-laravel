
<!-- Calendly inline widget begin -->

<!-- Calendly inline widget end -->

<?php /**PATH D:\Project\synex-bootstrap-laravel\resources\views\Frontend\layout\calendly.blade.php ENDPATH**/ ?>