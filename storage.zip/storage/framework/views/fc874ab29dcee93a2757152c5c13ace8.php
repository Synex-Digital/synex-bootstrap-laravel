<?php $__env->startSection('content'); ?>
    
    <?php
        $services = [
            [
                'name' => 'Management Software',
                'description' => 'ERP Development, CRM Development, Project Management Software, Business Intelligence Software',
                'url' => route('service.software'),
            ],
            [
                'name' => 'Software as a Service (SaaS)',
                'description' => 'SaaS Application Development, Product Design, Maintenance and Support',
                'url' => route('service.saas'),
            ],
            [
                'name' => 'Web Development',
                'description' => 'Frontend/Backend, Full Stack/CMS, E-commerce Development, Maintenance and Support',
                'url' => route('service.web-dev'),
            ],
            [
                'name' => 'Mobile App Development',
                'description' => 'iOS/Android, Custom Development, Maintenance and Support',
                'url' => route('service.mobile-app'),
            ],
            [
                'name' => 'Digital Marketing',
                'description' => 'SEO, Google Ads, Meta Ads,  Social Media Management, LinkedIn Ads',
                'url' => route('service.digital-marketing'),
            ],
            [
                'name' => 'UI UX Design',
                'description' => 'User Interface/Experience Design,  Visual Design, User Testing',
                'url' => route('service.uiux'),
            ],
            [
                'name' => 'Graphics Design',
                'description' => 'Branding and Identity, Print Design, Digital Design,  Illustration,  3D Design',
                'url' => route('service.graphics-design'),
            ],
            [
                'name' => 'Video Editing',
                'description' => 'Post-Production,  Motion Graphics,  Video Production, Editing for Social Media',
                'url' => route('service.video-edit'),
            ],
        ];
        $testimonials = [
            [
                'message' =>
                    'I could not be happier with the website that Synex Digital created for my business. They took my ideas and turned them into a stunning, user-friendly website that exceeded my expectations.',
                'image' => asset('Frontend/images/tahsan.webp'),
                'client' => 'Mahadi Tahsan',
                'title' => 'Instructor',
            ],
            [
                'message' =>
                    'Working with Synex Digital has been a game-changer for our online visibility. Their SEO team’s expertise and strategies have propelled our website to the top of search engine rankings. Glad to hire them on a monthly basis.',
                'image' => asset('Frontend/images/sydul.webp'),
                'client' => 'MD Sydul Amin',
                'title' => 'Python Developer',
            ],
            [
                'message' =>
                    'Synex Digital’s management software completely revolutionized our school. For schools that require reliability, streamlined administration, user-friendly design, and responsive assistance redefine efficiency!',
                'image' => asset('Frontend/images/shawon.webp'),
                    'client' => 'Shawon Islam',
                'title' => 'One Year Academy',
            ],
        ];
    ?>
    <?php echo $__env->make('Frontend.layout.calendly', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Hero section -->
    <section class="container-fluid">
        <div class="container py-md-5">
            <div class="row py-4 d-flex align-items-center">
                <div class="col-md-6 order-2 order-md-1">
                    <h1 class="leading-font-main">Business IT Solutions <br>
                        <span class="leading-pill">Pioneering Excellence for</span> <br>
                        Your Technological Needs
                    </h1>
                    <h2 class="leading-font-second pt-4">
                        As a Digital Solutions Expert, we are excited to help you through our extensive variety of services to elevate your business in the ever-changing digital landscape. Synex Digital's commercial IT solutions reflect our dedication to excellence. We are your one-stop technological solution supplier, meeting your business's particular demands with precision and competence.
                    </h2>
                    <a href="<?php echo e(route('projects')); ?>" class="btn btn-primary btn-default  mt-4">Explore Our Portfolio</a>
                </div>
                <div class="col-md-6 order-1 order-md-2 d-flex justify-content-center">
                    <img src="<?php echo e(asset('Frontend')); ?>/images/Frame 9.png" width="100%" alt="Synex Digital">
                </div>
            </div>
        </div>
    </section>

    <!-- Services -->
    <section class="container-fluid">
        <div class="container py-5">
            <div class="row mb-4 text-center">
                <p class="section-name font-main">Our Services</p>
                <h3 class="section-title font-second">Services We Provide</h3>
            </div>
            <div class="row py-5 g-5">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                        <?php if (isset($component)) { $__componentOriginalb27a5a249f71ab571a403abfa68dc52f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb27a5a249f71ab571a403abfa68dc52f = $attributes; } ?>
<?php $component = App\View\Components\ServiceCard::resolve(['title' => ''.e($service['name']).'','url' => ''.e($service['url']).'','description' => ''.e($service['description']).'','id' => ''.e($key + 1).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ServiceCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb27a5a249f71ab571a403abfa68dc52f)): ?>
<?php $attributes = $__attributesOriginalb27a5a249f71ab571a403abfa68dc52f; ?>
<?php unset($__attributesOriginalb27a5a249f71ab571a403abfa68dc52f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb27a5a249f71ab571a403abfa68dc52f)): ?>
<?php $component = $__componentOriginalb27a5a249f71ab571a403abfa68dc52f; ?>
<?php unset($__componentOriginalb27a5a249f71ab571a403abfa68dc52f); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- Our Records  -->
    <section class="container-fluid">
        <div class="container py-md-5">
            <div class="row mb-4 text-center">
                <p class="section-name font-main">Our Records</p>
                <h3 class="section-title font-second m-auto w-505">Navigating the IT Landscape with Precision</h3>
            </div>
            <div class="row py-5 g-5">
                <div class="col-md-6  px-md-5">
                    <!-- <div class="image-record"> </div> -->
                    <img class="image-record" src="<?php echo e(asset('Frontend')); ?>/images/Frame10.webp" alt="Synex digital Record">
                </div>
                <div class="col-md-6">
                    <div class="text-record">
                        <p>
                            At Synex Digital, our track record speaks for itself. We’ve successfully navigated the complex IT landscape, delivering innovative solutions that drive measurable results. From bespoke software development to advanced digital marketing strategies, our team’s expertise and commitment to excellence have earned us a reputation for reliability and success in the industry.
                        </p>
                        <p>
                            Our portfolio showcases a diverse range of projects, reflecting our ability to adapt to various business needs and industry demands. Whether it's optimizing web performance, enhancing user experiences, or implementing cutting-edge technologies, our projects consistently exceed client expectations. This proven track record not only highlights our technical prowess but also our ability to deliver on time and within budget.
                        </p>
                        <p>
                            We believe in the power of data-driven decisions and meticulous project management. Our precise approach ensures that every solution is tailored to our clients' specific goals, fostering long-term partnerships built on trust and results. Our success is measured not just by completed projects, but by the growth and satisfaction of our clients who repeatedly choose us as their IT partner.
                        </p>
                        <p>
                            Synex Digital’s commitment to precision and excellence has positioned us as a leader in the IT services sector. By continuously evolving and embracing the latest technological advancements, we ensure that our clients stay ahead of the competition. Trust in our proven expertise to guide your business through the ever-changing digital landscape with confidence and clarity.
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Our Project  -->
    <section class="container-fluid">
        <div class="container py-5">
            <div class="row  text-center mb-4">
                <p class="section-name font-main">Our Projects</p>
                <h3 class="section-title font-second">Project We Develop</h3>
            </div>

            <div class="row g-3">
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <?php if (isset($component)) { $__componentOriginalb009b6bea983337cad65fcfb8a10d717 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb009b6bea983337cad65fcfb8a10d717 = $attributes; } ?>
<?php $component = App\View\Components\ProjectCard::resolve(['title' => ''.e($project['title']).'','name' => ''.e($project['name']).'','description' => ''.e($project['description']).'','category' => ''.e($project['category']).'','image' => ''.e($project['image']).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('project-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProjectCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb009b6bea983337cad65fcfb8a10d717)): ?>
<?php $attributes = $__attributesOriginalb009b6bea983337cad65fcfb8a10d717; ?>
<?php unset($__attributesOriginalb009b6bea983337cad65fcfb8a10d717); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb009b6bea983337cad65fcfb8a10d717)): ?>
<?php $component = $__componentOriginalb009b6bea983337cad65fcfb8a10d717; ?>
<?php unset($__componentOriginalb009b6bea983337cad65fcfb8a10d717); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="text-center">
                    <a href="<?php echo e(route('projects')); ?>" class="btn btn-primary btn-default mt-md-4">View All</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <div class="container-fluid py-5 bg-testimonial">
        <div class="container">
            <div class="row mb-4 text-center">
                <p class="section-name text-white">Testimonials</p>
                <h3 class="section-title font-second">Opinions of Our Clients</h3>
            </div>

            <div class="row g-3">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <?php if (isset($component)) { $__componentOriginal06cf8767fb67761f17058e74be611369 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06cf8767fb67761f17058e74be611369 = $attributes; } ?>
<?php $component = App\View\Components\Testimonial::resolve(['message' => ''.e($testimonial['message']).'','image' => ''.e($testimonial['image']).'','client' => ''.e($testimonial['client']).'','title' => ''.e($testimonial['title']).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('testimonial'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Testimonial::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06cf8767fb67761f17058e74be611369)): ?>
<?php $attributes = $__attributesOriginal06cf8767fb67761f17058e74be611369; ?>
<?php unset($__attributesOriginal06cf8767fb67761f17058e74be611369); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06cf8767fb67761f17058e74be611369)): ?>
<?php $component = $__componentOriginal06cf8767fb67761f17058e74be611369; ?>
<?php unset($__componentOriginal06cf8767fb67761f17058e74be611369); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- Our blogs -->
    <?php if($blogs): ?>
        <div class="container-fluid py-5">
            <div class="container">
                <div class="row mb-4 text-center">
                    <p class="section-name">Our Blogs</p>
                    <h3 class="section-title font-second">Latest Blogs and Articles</h3>
                </div>

                <div class="row gx-3 py-3">
                    <div class="col-md-5 pb-3">
                        <?php if($blogs['popular']): ?>
                            <article class="card-1">
                                <div class="card-body">
                                    <a href="<?php echo e(route('blog.view', $blogs['popular']['slug'])); ?>">
                                        <img src="<?php echo e($blogs['popular']['image']); ?>" width="100%"
                                            style="border-radius: 0.5rem;" alt="Synex Digital">
                                    </a>

                                    <div class="pt-3">
                                        <div class="d-flex gap-3 mb-1 justify-content-between">
                                            <!-- Authors -->
                                            <div class="d-flex gap-1 align-items-center">
                                                <svg width="15" height="14" viewBox="0 0 18 17" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M13.9854 14.1039C13.4031 13.333 12.6498 12.7078 11.7847 12.2776C10.9197 11.8473 9.96655 11.6239 9.00042 11.6248C8.03429 11.6239 7.08115 11.8473 6.2161 12.2776C5.35104 12.7078 4.5977 13.333 4.01542 14.1039M13.9854 14.1039C15.1217 13.0932 15.923 11.761 16.2847 10.284C16.6465 8.80694 16.5506 7.25483 16.01 5.83349C15.4693 4.41215 14.5094 3.18873 13.2574 2.3255C12.0055 1.46227 10.5207 1 9 1C7.4793 1 5.99453 1.46227 4.74259 2.3255C3.49065 3.18873 2.53069 4.41215 1.99003 5.83349C1.44937 7.25483 1.35354 8.80694 1.71527 10.284C2.07699 11.761 2.87917 13.0932 4.01542 14.1039M13.9854 14.1039C12.6138 15.3274 10.8384 16.0024 9.00042 15.9998C7.16211 16.0026 5.38728 15.3276 4.01542 14.1039M11.5004 6.62475C11.5004 7.2878 11.237 7.92368 10.7682 8.39252C10.2993 8.86136 9.66346 9.12475 9.00042 9.12475C8.33738 9.12475 7.70149 8.86136 7.23265 8.39252C6.76381 7.92368 6.50042 7.2878 6.50042 6.62475C6.50042 5.96171 6.76381 5.32583 7.23265 4.85699C7.70149 4.38815 8.33738 4.12475 9.00042 4.12475C9.66346 4.12475 10.2993 4.38815 10.7682 4.85699C11.237 5.32583 11.5004 5.96171 11.5004 6.62475Z"
                                                        stroke="black" stroke-width="1.5" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg>
                                                <p class="card-nap"><?php echo e($blogs['popular']['author']); ?></p>
                                            </div>
                                            <!-- Comments -->
                                            <div class="d-flex gap-1 align-items-center"><?php echo e($blogs['popular']['view']); ?><p
                                                    class="card-nap">View</p>
                                            </div>
                                        </div>

                                        <a href="<?php echo e(route('blog.view', $blogs['popular']['slug'])); ?>"
                                            class="card-title font-700 mb-0"><?php echo e($blogs['popular']['title']); ?></a>
                                        <p class="pt-2"><?php echo e($blogs['popular']['description']); ?></p>
                                    </div>
                                </div>
                            </article>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-7">
                        <div class="row g-3">
                            <?php $__currentLoopData = $blogs['blogs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6">
                                    <?php if (isset($component)) { $__componentOriginal1b0f9f0b38527e9ba03e54e55969d8ca = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b0f9f0b38527e9ba03e54e55969d8ca = $attributes; } ?>
<?php $component = App\View\Components\IndexBlog::resolve(['author' => ''.e($blogs['popular']['author']).'','count' => ''.e($blog['view']).'','title' => ''.e($blog['title']).'','image' => ''.e($blog['image']).'','slug' => ''.e($blog['slug']).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('index-blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\IndexBlog::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b0f9f0b38527e9ba03e54e55969d8ca)): ?>
<?php $attributes = $__attributesOriginal1b0f9f0b38527e9ba03e54e55969d8ca; ?>
<?php unset($__attributesOriginal1b0f9f0b38527e9ba03e54e55969d8ca); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b0f9f0b38527e9ba03e54e55969d8ca)): ?>
<?php $component = $__componentOriginal1b0f9f0b38527e9ba03e54e55969d8ca; ?>
<?php unset($__componentOriginal1b0f9f0b38527e9ba03e54e55969d8ca); ?>
<?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="text-center">
                        <a href="<?php echo e(route('blogs')); ?>" class="btn btn-primary btn-default mt-3 mt-md-4">View All</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Collaborate -->
    <?php if (isset($component)) { $__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c = $attributes; } ?>
<?php $component = App\View\Components\Collaborate::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('collaborate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Collaborate::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c)): ?>
<?php $attributes = $__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c; ?>
<?php unset($__attributesOriginalc36c8ce0cb99479c7d9e92251f931f7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c)): ?>
<?php $component = $__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c; ?>
<?php unset($__componentOriginalc36c8ce0cb99479c7d9e92251f931f7c); ?>
<?php endif; ?>

    <!-- News Letter-->
    <?php if (isset($component)) { $__componentOriginal476d5595d47c472a8f67121eca35cf7d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal476d5595d47c472a8f67121eca35cf7d = $attributes; } ?>
<?php $component = App\View\Components\Newsletter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('newsletter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Newsletter::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal476d5595d47c472a8f67121eca35cf7d)): ?>
<?php $attributes = $__attributesOriginal476d5595d47c472a8f67121eca35cf7d; ?>
<?php unset($__attributesOriginal476d5595d47c472a8f67121eca35cf7d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal476d5595d47c472a8f67121eca35cf7d)): ?>
<?php $component = $__componentOriginal476d5595d47c472a8f67121eca35cf7d; ?>
<?php unset($__componentOriginal476d5595d47c472a8f67121eca35cf7d); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\synex-bootstrap-laravel\resources\views\Frontend\index.blade.php ENDPATH**/ ?>